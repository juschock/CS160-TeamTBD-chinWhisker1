from django.apps import AppConfig


class ProductMgtConfig(AppConfig):
    name = 'shaver_mgt'
